


import json
import os

from odin_vision.api.internal.exceptions import CouldNotCreateDatasetInPathError, CouldNotFindDatasetError

class ClassificationSplit:
    def __init__(self, images, labels):
        self.images = images
        self.labels = labels

class DetectionSplit:
    def __init__(self, images):
        self.images = {}

class OdinDataset:
    def __init__(self, name: str | None = None, project: OdinProject | None = None, path: str | None = None, allow_creation: bool = False, **kwargs):
        self.name = name
        self.allow_creation = allow_creation
        self.project = project
        
        self._check_dataset_path(path)
        self.path = path
        
        self.staging = self._get_split("staging")
        self.train = self._get_split("train")
        self.val = self._get_split("val")
        
        self.version = self._get_version()
        self.status = self._get_status()
        
    def _status_sum_staging(self, **kwargs):
        if self.project.type == "classification":
            classes = []
            for x in os.walk(f"{self.path}\\staging"):
                if len(x[1]) > 0:
                    classes = x[1]

            final_sum = 0
            for dataset_class in classes:
                final_sum += sum(
                    len(files)
                    for _, _, files in os.walk(
                        f"{self.path}\\staging\\{dataset_class}"
                    )
                )

            return final_sum
        elif self.project.type == "detection":
            return sum(
                len(files)
                for _, _, files in os.walk(
                    f"{self.dataset_path}\\staging\\images"
                )
            )

    def _status_sum_train(self, **kwargs):
        if self.project.type == "classification":
            classes = []
            for x in os.walk(f"{self.path}\\staging"):
                if len(x[1]) > 0:
                    classes = x[1]

            final_sum = 0
            for dataset_class in classes:
                final_sum += sum(
                    len(files)
                    for _, _, files in os.walk(
                        f"{self.path}\\train\\{dataset_class}"
                    )
                )

            return final_sum
        elif self.project.type == "detection":
            return sum(
                len(files)
                for _, _, files in os.walk(
                    f"{self.dataset_path}\\train\\images"
                )
            )
        
    def _get_version(self):
        try:
            with open(f"{self.path}\\dataset.json", "r", encoding="utf8") as f:
                dataset_data = json.loads(f.read())
                self.version = dataset_data['version']
        except:
            self.version = "No version available."
            
    def _get_status(self):
        try:
            train_count = self._status_sum_train()
            staging_count = self._status_sum_staging()
            
            if staging_count > 0 and train_count > 0:
                self.status = "published_staging"
            elif staging_count > 0 and train_count == 0:
                self.status = "staging"
            elif train_count > 0 and staging_count == 0:
                self.status = "published"
            else:
                self.status = "empty"
        except:
            self.status = "No status available."
        
    def _get_split(self, split: str):
        def detection():
            split_images = []
            split_labels = []
            
            for _, _, images in os.walk(f"{self.path}\\{split}\\images"):
                split_images = images
                break
            
            for _, _, labels in os.walk(f"{self.path}\\{split}\\labels"):
                split_labels = labels
                break
                
            return DetectionSplit(split_images, split_labels)
        
        def classification():
            split_images = {}
            
            dataset_classes = []
            
            for _, dataset_folders, _ in os.walk(f"{self.path}\\{split}"):
                dataset_classes = dataset_folders                
                break
            
            for dataset_class in dataset_classes:
                class_images = []
                
                for _, _, images in os.walk(f"{self.path}\\{split}\\{dataset_class}"):
                    class_images = images
                    break
                
                split_images[dataset_class] = class_images
                
            return ClassificationSplit(split_images)
        
        if self.project.type == "classification":
            classification()
        elif self.project.type == "detection":
            detection()
        
    def _check_dataset_path(self, path):
        if not os.path.exists(path):
            if self.allow_creation:
                OdinDatasetsController(self.project).create(self.name)
            else:
                raise CouldNotFindDatasetError

class OdinDatasetsController:
    def __init__(self, project: OdinProject, datasets: list[OdinDataset] = []):
        self.project = project
        self.datasets = datasets
        
    def create(self, name: str | None = None, **kwargs):
        dataset_path = f"{self.project.path}\\datasets\\{name}"
        
        try:
            dataset_info = {
                "type": self.project.type,
                "version": "0.1.0"
            }

            with open(f"{dataset_path}\\dataset.json", "w", encoding="utf8") as wf:
                wf.write(json.dumps(dataset_info))

            with open(f"{dataset_path}\\snapshot.json", "w", encoding="utf8") as wf:
                wf.write(json.dumps({}))
            
            os.makedirs(f"{dataset_path}")
            os.makedirs(f"{dataset_path}\\staging")
            os.makedirs(f"{dataset_path}\\train")
            os.makedirs(f"{dataset_path}\\val")
            
            if self.project.type == "detection":
                os.makedirs(f"{dataset_path}\\staging\\images")
                os.makedirs(f"{dataset_path}\\staging\\labels")
                os.makedirs(f"{dataset_path}\\train\\images")
                os.makedirs(f"{dataset_path}\\train\\labels")
                os.makedirs(f"{dataset_path}\\val\\images")
                os.makedirs(f"{dataset_path}\\val\\labels")
            elif self.project_type == "classification":
                os.makedirs(f"{dataset_path}\\staging\\class_1")
        except:
            raise CouldNotCreateDatasetInPathError(dataset_path)
        
        new_dataset = OdinDataset(name, self.project, dataset_path)
        
        self.datasets.append(new_dataset)